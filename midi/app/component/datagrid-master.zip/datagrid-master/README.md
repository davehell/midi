## Nextras\Datagrid

Easy to use datagrid with powerfull API.

## Demo
See demos: http://nextras.cz/datagrid

## Installation

The best way to install is using [Composer](http://getcomposer.org/):

```sh
$ composer require nextras/datagrid
```

## Documentation

See documentation on new addon portal: http://nette.merxes.cz/addons/www/nextras/datagrid.
